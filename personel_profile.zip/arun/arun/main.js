var typed = new Typed(".text",{
    strings:["Python Developer", "Frontend Developer", "Business system"],
    typeSpeed : 10,
    backSpeed : 100,
    backDelay : 1000,
    loop : true
});